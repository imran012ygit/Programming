# leetcode-solutions
This repository contains detailed solutions to popular leetcode problems in multiple programming languages.

Check out the full list of problems categorized by topics and patterns at [algomaster.io](https://algomaster.io/practice/dsa-patterns)
